package fr.younup.helloworldcicd

class BootStrap {

    def init = { servletContext ->
    }
    def destroy = {
    }
}
